package com.diagpro.assistant.detection

import android.os.Handler
import android.os.Looper
import com.diagpro.assistant.util.Constants

// ═══════════════════════════════════════════════════════
//  مستخرج أكواد DTC — منفصل وقابل للاختبار
// ═══════════════════════════════════════════════════════

object DtcExtractor {

    fun extract(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        return Constants.DTC_REGEX.findAll(text)
            .map { it.value.uppercase() }
            .distinct()
            .filter { isValid(it) }
            .sortedWith(compareBy({ it[0] }, { it }))
            .toList()
    }

    fun isValid(code: String): Boolean {
        if (code.length != 5) return false
        val prefix = code[0].uppercaseChar()
        if (prefix != 'P' && prefix != 'C' && prefix != 'B' && prefix != 'U') return false
        if (!code.substring(1).all { it.isDigit() }) return false
        if (code.substring(1) == "0000") return false
        return true
    }

    fun hasChanged(old: List<String>, new_: List<String>): Boolean =
        old.toSet() != new_.toSet()
}

// ═══════════════════════════════════════════════════════
//  Debouncer — يمنع الاستدعاء المتكرر
// ═══════════════════════════════════════════════════════

class DtcDebouncer {
    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null

    fun debounce(action: () -> Unit) {
        pending?.let { handler.removeCallbacks(it) }
        val task = Runnable { action() }
        pending = task
        handler.postDelayed(task, Constants.DEBOUNCE_MS)
    }

    fun cancel() {
        pending?.let { handler.removeCallbacks(it) }
        pending = null
    }
}
