package com.diagpro.assistant.data.local

import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow

// ═══════════════════════════════════════════════════════
//  Type Converters
// ═══════════════════════════════════════════════════════

class Converters {
    private val gson = Gson()

    @TypeConverter fun listToJson(v: List<String>): String = gson.toJson(v)
    @TypeConverter fun jsonToList(v: String): List<String> = try {
        gson.fromJson<List<String>>(v, object : TypeToken<List<String>>() {}.type) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    @TypeConverter fun mapToJson(v: Map<String, String>): String = gson.toJson(v)
    @TypeConverter fun jsonToMap(v: String): Map<String, String> = try {
        gson.fromJson<Map<String, String>>(v, object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
    } catch (e: Exception) { emptyMap() }
}

// ═══════════════════════════════════════════════════════
//  جدول الحالات السريعة (من الـ Overlay مباشرة)
// ═══════════════════════════════════════════════════════

@Entity(tableName = "saved_cases")
@TypeConverters(Converters::class)
data class CaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id               : Long = 0,
    val timestamp        : Long = System.currentTimeMillis(),
    val primaryCode      : String,
    val dtcCodes         : List<String>,
    val vehicleMake      : String = "",
    val vehicleModel     : String = "",
    val vehicleYear      : Int    = 0,
    val faultNameAr      : String,
    val description      : String,
    val causes           : List<String>,
    val steps            : List<String>,
    val severity         : String,
    val techNotes        : String = "",
    val isSolved         : Boolean = false,
    val aiSource         : String = "LOCAL",   // LOCAL | AI_CLAUDE | AI_OPENAI | DIAGPRO_CLOUD
    val isSynced         : Boolean = false
)

// ═══════════════════════════════════════════════════════
//  جدول تقارير الصيانة الكاملة
// ═══════════════════════════════════════════════════════

@Entity(tableName = "repair_reports")
@TypeConverters(Converters::class)
data class ReportEntity(
    @PrimaryKey
    val reportId          : String,
    val createdAt         : Long = System.currentTimeMillis(),
    val updatedAt         : Long = System.currentTimeMillis(),
    val workshopId        : String = "",
    val technicianName    : String = "",

    // السيارة
    val vehicleMake       : String = "",
    val vehicleModel      : String = "",
    val vehicleYear       : Int = 0,
    val vehicleVin        : String = "",
    val vehicleMileage    : Int = 0,
    val vehicleSource     : String = "MANUAL",   // AUTO_DETECTED | MANUAL_ENTRY

    // قبل الإصلاح
    val preRepairCodes    : List<String> = emptyList(),
    val preRepairSnapshot : Map<String, String> = emptyMap(),

    // الإصلاح
    val diagnosis         : String = "",
    val partsReplaced     : List<String> = emptyList(),
    val laborDescription  : String = "",
    val technicianNotes   : String = "",

    // بعد الإصلاح
    val postRepairCodes   : List<String> = emptyList(),
    val confirmedSolved   : Boolean = false,
    val roadTestDone      : Boolean = false,

    // AI
    val aiSuggested       : String = "",
    val aiWasCorrect      : Boolean? = null,

    // حالة
    val status            : String = "DRAFT",    // DRAFT | COMPLETED | SYNCED
    val isSynced          : Boolean = false
)

// ═══════════════════════════════════════════════════════
//  DAOs
// ═══════════════════════════════════════════════════════

@Dao
interface CaseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(case_: CaseEntity): Long

    @Update suspend fun update(case_: CaseEntity)

    @Query("SELECT * FROM saved_cases ORDER BY timestamp DESC")
    fun getAll(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM saved_cases WHERE isSolved = 0 ORDER BY timestamp DESC")
    fun getOpen(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM saved_cases WHERE id = :id")
    suspend fun getById(id: Long): CaseEntity?

    @Query("UPDATE saved_cases SET isSolved = 1 WHERE id = :id")
    suspend fun markSolved(id: Long)

    @Query("UPDATE saved_cases SET techNotes = :notes WHERE id = :id")
    suspend fun updateNotes(id: Long, notes: String)

    @Query("UPDATE saved_cases SET isSynced = 1 WHERE id = :id")
    suspend fun markSynced(id: Long)

    @Delete suspend fun delete(case_: CaseEntity)
}

@Dao
interface ReportDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: ReportEntity)

    @Update suspend fun update(report: ReportEntity)

    @Query("SELECT * FROM repair_reports ORDER BY createdAt DESC")
    fun getAll(): Flow<List<ReportEntity>>

    @Query("SELECT * FROM repair_reports WHERE reportId = :id")
    suspend fun getById(id: String): ReportEntity?

    @Query("SELECT * FROM repair_reports WHERE isSynced = 0 AND status = 'COMPLETED'")
    suspend fun getPendingSync(): List<ReportEntity>

    @Query("UPDATE repair_reports SET status = :status, updatedAt = :ts WHERE reportId = :id")
    suspend fun updateStatus(id: String, status: String, ts: Long = System.currentTimeMillis())

    @Query("UPDATE repair_reports SET isSynced = 1 WHERE reportId = :id")
    suspend fun markSynced(id: String)

    @Delete suspend fun delete(report: ReportEntity)
}

// ═══════════════════════════════════════════════════════
//  AppDatabase
// ═══════════════════════════════════════════════════════

@Database(
    entities = [CaseEntity::class, ReportEntity::class],
    version  = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun caseDao(): CaseDao
    abstract fun reportDao(): ReportDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "diagpro_v5.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
