package com.diagpro.assistant.util

object Constants {

    // ═══════════════════════════════════════════════
    //  ⚠️ غيّر هذا لاسم حزمة X-Diag الفعلي
    //  adb shell pm list packages | grep -i xdiag
    // ═══════════════════════════════════════════════
    const val XDIAG_PACKAGE_NAME       = "com.xdiag.android"

    // ═══════════════════════════════════════════════
    //  Overlay Broadcast Actions
    // ═══════════════════════════════════════════════
    const val ACTION_DTC_DETECTED      = "com.diagpro.ACTION_DTC_DETECTED"
    const val ACTION_VEHICLE_DETECTED  = "com.diagpro.ACTION_VEHICLE_DETECTED"
    const val EXTRA_DTC_LIST           = "extra_dtc_list"
    const val EXTRA_VEHICLE_INFO       = "extra_vehicle_info"

    // ═══════════════════════════════════════════════
    //  Notification
    // ═══════════════════════════════════════════════
    const val CHANNEL_ID_OVERLAY       = "diagpro_overlay"
    const val NOTIF_ID_OVERLAY         = 1001

    // ═══════════════════════════════════════════════
    //  SharedPreferences
    // ═══════════════════════════════════════════════
    const val PREFS_NAME               = "diagpro_prefs"
    const val PREF_AI_PROVIDER         = "ai_provider"          // CLAUDE | OPENAI | LOCAL
    const val PREF_CLAUDE_KEY          = "claude_api_key"
    const val PREF_OPENAI_KEY          = "openai_api_key"
    const val PREF_CLOUD_URL           = "diagpro_cloud_url"
    const val PREF_CLOUD_KEY           = "diagpro_cloud_key"
    const val PREF_WORKSHOP_ID         = "workshop_id"
    const val PREF_TECHNICIAN_NAME     = "technician_name"
    const val PREF_USE_CLOUD           = "use_diagpro_cloud"

    // ═══════════════════════════════════════════════
    //  DiagPro Cloud API (SaaS)
    // ═══════════════════════════════════════════════
    const val DEFAULT_CLOUD_URL        = "https://api.diagpro.tech/v1"
    const val ENDPOINT_ANALYZE         = "/dtc/analyze"
    const val ENDPOINT_SAVE_REPORT     = "/reports"
    const val ENDPOINT_WORKSHOP_STATS  = "/workshops/stats"
    const val API_TIMEOUT_SEC          = 20L

    // ═══════════════════════════════════════════════
    //  Detection
    // ═══════════════════════════════════════════════
    const val DEBOUNCE_MS              = 800L
    val DTC_REGEX                      = Regex("\\b([PCBU][0-9]{4})\\b")

    // Vehicle detection patterns
    val VEHICLE_YEAR_REGEX             = Regex("\\b(19[8-9]\\d|20[0-2]\\d)\\b")
    val VIN_REGEX                      = Regex("[A-HJ-NPR-Z0-9]{17}")

    // ═══════════════════════════════════════════════
    //  Local Assets
    // ═══════════════════════════════════════════════
    const val DTC_DATABASE_FILE        = "dtc_database.json"

    // ═══════════════════════════════════════════════
    //  Overlay UI
    // ═══════════════════════════════════════════════
    const val BUBBLE_DEFAULT_X         = 20
    const val BUBBLE_DEFAULT_Y         = 300
}
