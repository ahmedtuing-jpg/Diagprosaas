package com.diagpro.assistant.accessibility

import android.view.accessibility.AccessibilityNodeInfo

object ScreenTextReader {

    private const val MAX_DEPTH = 30

    fun readAll(root: AccessibilityNodeInfo?): String {
        root ?: return ""
        val sb = StringBuilder()
        traverse(root, sb, 0)
        return sb.toString()
    }

    private fun traverse(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > MAX_DEPTH) return
        try {
            if (!node.text.isNullOrBlank())              sb.append(node.text).append(" ")
            if (!node.contentDescription.isNullOrBlank()) sb.append(node.contentDescription).append(" ")
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                traverse(child, sb, depth + 1)
                child.recycle()
            }
        } catch (e: Exception) { /* تجاهل أخطاء العقد المنفردة */ }
    }
}
