package com.diagpro.assistant.analysis

import android.content.Context
import android.util.Log
import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.cloud.CloudResult
import com.diagpro.assistant.cloud.DiagProCloudClient
import com.diagpro.assistant.util.Constants
import com.diagpro.assistant.util.getCloudKey
import com.diagpro.assistant.util.getCloudUrl
import com.diagpro.assistant.util.getWorkshopId
import com.diagpro.assistant.util.isCloudEnabled
import com.diagpro.assistant.util.isOnline
import com.diagpro.assistant.util.prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * مستودع التحليل المركزي
 *
 * ترتيب الأولوية:
 * 1. DiagPro Cloud (أذكى — بيانات مجمّعة من ورش)
 * 2. Claude AI / OpenAI (ذكي — عام)
 * 3. قاعدة محلية (بلا إنترنت)
 */
class AnalysisRepository(private val context: Context) {

    private val TAG           = "AnalysisRepo"
    private val localAnalyzer = LocalAnalyzer(context)
    private val cache         = mutableMapOf<String, AnalysisResult>()

    suspend fun analyze(code: String, vehicle: VehicleInfo? = null): AnalysisResult {
        val key = "${code.uppercase()}_${vehicle?.displayName() ?: ""}"
        cache[key]?.let { return it }

        val result = withContext(Dispatchers.IO) {
            val vehicleHint = vehicle?.displayName() ?: ""

            // ── 1. DiagPro Cloud ──────────────────────────────
            if (context.isCloudEnabled() && context.isOnline()) {
                val r = tryCloud(code, vehicle)
                if (r != null) { cache[key] = r; return@withContext r }
            }

            // ── 2. AI (Claude أو OpenAI) ─────────────────────
            val aiResult = tryAi(code, vehicleHint)
            if (aiResult != null) { cache[key] = aiResult; return@withContext aiResult }

            // ── 3. Local fallback ─────────────────────────────
            val local = localAnalyzer.analyze(code)
            cache[key] = local
            local
        }
        return result
    }

    private suspend fun tryCloud(code: String, vehicle: VehicleInfo?): AnalysisResult? {
        return try {
            val client = DiagProCloudClient(
                baseUrl    = context.getCloudUrl(),
                apiKey     = context.getCloudKey(),
                workshopId = context.getWorkshopId()
            )
            when (val r = client.analyze(
                code        = code,
                vehicleMake = vehicle?.make ?: "",
                vehicleModel= vehicle?.model ?: "",
                vehicleYear = vehicle?.year ?: 0
            )) {
                is CloudResult.Success -> r.data
                is CloudResult.Error   -> { Log.w(TAG, "Cloud: ${r.message}"); null }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cloud error: ${e.message}")
            null
        }
    }

    private suspend fun tryAi(code: String, vehicleHint: String): AnalysisResult? {
        val prefs    = context.prefs()
        val provider = prefs.getString(Constants.PREF_AI_PROVIDER, "LOCAL") ?: "LOCAL"
        if (provider == "LOCAL") return null
        if (!context.isOnline()) return null

        return try {
            when (provider) {
                "CLAUDE" -> {
                    val key = prefs.getString(Constants.PREF_CLAUDE_KEY, "") ?: ""
                    if (key.isBlank()) null
                    else ClaudeAnalyzer.analyze(code, key, vehicleHint)
                }
                "OPENAI" -> {
                    val key = prefs.getString(Constants.PREF_OPENAI_KEY, "") ?: ""
                    if (key.isBlank()) null
                    else OpenAiAnalyzer.analyze(code, key, vehicleHint)
                }
                else -> null
            }
        } catch (e: Exception) {
            Log.w(TAG, "AI error: ${e.message}")
            null
        }
    }

    fun clearCache() = cache.clear()
    fun localDbSize() = localAnalyzer.size()
}
