package com.diagpro.assistant.ui.adapter

import android.view.*
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.diagpro.assistant.R
import com.diagpro.assistant.analysis.model.CauseProbability

// ═══════════════════════════════════════════════════════
//  DtcChipAdapter — شرائح أكواد العطل الأفقية
// ═══════════════════════════════════════════════════════

class DtcChipAdapter(
    private var codes        : List<String>,
    private var selected     : String,
    private val onChipClick  : (String) -> Unit
) : RecyclerView.Adapter<DtcChipAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvCode: TextView = v.findViewById(R.id.tvChipCode)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_dtc_chip, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val code = codes[pos]
        h.tvCode.text = code
        h.tvCode.isSelected = code == selected
        h.tvCode.setBackgroundResource(
            if (code == selected) R.drawable.bg_chip_selected else R.drawable.bg_chip_default
        )
        h.tvCode.setTextColor(
            if (code == selected)
                h.tvCode.context.resources.getColor(R.color.chip_text_selected)
            else
                h.tvCode.context.resources.getColor(R.color.text_primary)
        )
        h.itemView.setOnClickListener {
            val prev = selected; selected = code
            notifyItemChanged(codes.indexOf(prev)); notifyItemChanged(pos)
            onChipClick(code)
        }
    }

    override fun getItemCount() = codes.size

    fun getSelectedCode() = selected

    fun updateCodes(newCodes: List<String>) {
        codes = newCodes
        if (!codes.contains(selected)) selected = codes.firstOrNull() ?: ""
        notifyDataSetChanged()
    }
}

// ═══════════════════════════════════════════════════════
//  CauseAdapter — الأسباب المحتملة
// ═══════════════════════════════════════════════════════

class CauseAdapter(private val items: List<String>) :
    RecyclerView.Adapter<CauseAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvNum  : TextView = v.findViewById(R.id.tvItemNumber)
        val tvText : TextView = v.findViewById(R.id.tvItemText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_cause_step, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        h.tvNum.text  = "${pos + 1}"
        h.tvText.text = items[pos]
        h.tvNum.setBackgroundResource(R.drawable.bg_number_cause)
    }

    override fun getItemCount() = items.size
}

// ═══════════════════════════════════════════════════════
//  StepAdapter — خطوات الفحص
// ═══════════════════════════════════════════════════════

class StepAdapter(private val items: List<String>) :
    RecyclerView.Adapter<StepAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvNum  : TextView = v.findViewById(R.id.tvItemNumber)
        val tvText : TextView = v.findViewById(R.id.tvItemText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_cause_step, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        h.tvNum.text  = "${pos + 1}"
        h.tvText.text = items[pos]
        h.tvNum.setBackgroundResource(R.drawable.bg_number_step)
    }

    override fun getItemCount() = items.size
}

// ═══════════════════════════════════════════════════════
//  ProbabilityAdapter — نسب الاحتمال من DiagPro Cloud
// ═══════════════════════════════════════════════════════

class ProbabilityAdapter(private val items: List<CauseProbability>) :
    RecyclerView.Adapter<ProbabilityAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvCause   : TextView    = v.findViewById(R.id.tvProbCause)
        val tvPercent : TextView    = v.findViewById(R.id.tvProbPercent)
        val pbBar     : ProgressBar = v.findViewById(R.id.pbProbability)
        val tvCount   : TextView    = v.findViewById(R.id.tvCaseCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_probability, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = items[pos]
        h.tvCause.text   = item.cause
        h.tvPercent.text = "${item.probability}%"
        h.pbBar.progress = item.probability
        if (item.caseCount > 0) {
            h.tvCount.visibility = View.VISIBLE
            h.tvCount.text = "${item.caseCount} حالة"
        } else h.tvCount.visibility = View.GONE
    }

    override fun getItemCount() = items.size
}
