package com.diagpro.assistant.analysis

import android.content.Context
import android.util.Log
import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.AnalysisSource
import com.diagpro.assistant.analysis.model.Severity
import com.diagpro.assistant.util.Constants
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

class LocalAnalyzer(private val context: Context) {

    private val TAG = "LocalAnalyzer"
    private var db: Map<String, LocalEntry> = emptyMap()
    private var loaded = false

    private fun ensureLoaded() {
        if (loaded) return
        try {
            val json = context.assets.open(Constants.DTC_DATABASE_FILE)
                .bufferedReader().use { it.readText() }
            val parsed = Gson().fromJson(json, LocalDatabase::class.java)
            db = parsed.codes.associateBy { it.code.uppercase() }
            loaded = true
            Log.d(TAG, "✅ تم تحميل ${db.size} كود")
        } catch (e: Exception) {
            Log.e(TAG, "❌ فشل تحميل القاعدة: ${e.message}")
        }
    }

    fun analyze(code: String): AnalysisResult {
        ensureLoaded()
        val entry = db[code.uppercase()]
        return if (entry != null) {
            AnalysisResult(
                code        = entry.code,
                nameAr      = entry.nameAr,
                description = entry.description,
                causes      = entry.causes,
                steps       = entry.steps,
                severity    = parseSeverity(entry.severity),
                specialNotes= entry.specialNotes ?: "",
                isFound     = true,
                source      = AnalysisSource.LOCAL
            )
        } else notFound(code)
    }

    private fun notFound(code: String) = AnalysisResult(
        code        = code,
        nameAr      = "الكود غير موجود في القاعدة المحلية",
        description = "الكود ($code) غير موجود حاليًا في قاعدة التحليل المحلية.\n" +
                      "يمكن حفظه ومراجعته لاحقًا أو تفعيل التحليل عبر Claude/OpenAI من الإعدادات.",
        causes      = listOf(
            "قد يكون كودًا خاصًا بالمصنّع (Manufacturer Specific)",
            "قد يكون كودًا نادرًا غير مُدرَج بعد في القاعدة"
        ),
        steps       = listOf(
            "احفظ الحالة لمراجعتها لاحقًا",
            "تحقق من الكود مرة أخرى في X-Diag",
            "فعّل تحليل AI من الإعدادات إذا كان متاحًا"
        ),
        severity    = Severity.MEDIUM,
        isFound     = false,
        source      = AnalysisSource.LOCAL
    )

    private fun parseSeverity(s: String) = try {
        Severity.valueOf(s.uppercase())
    } catch (e: Exception) { Severity.MEDIUM }

    fun size(): Int { ensureLoaded(); return db.size }

    // ═══ نماذج JSON ═══
    data class LocalDatabase(
        val codes: List<LocalEntry> = emptyList()
    )
    data class LocalEntry(
        @SerializedName("code")          val code        : String,
        @SerializedName("name_ar")       val nameAr      : String,
        @SerializedName("description")   val description : String,
        @SerializedName("causes")        val causes      : List<String>,
        @SerializedName("steps")         val steps       : List<String>,
        @SerializedName("severity")      val severity    : String,
        @SerializedName("special_notes") val specialNotes: String? = null
    )
}
