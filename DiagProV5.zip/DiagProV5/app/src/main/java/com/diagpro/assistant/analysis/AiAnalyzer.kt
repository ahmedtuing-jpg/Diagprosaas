package com.diagpro.assistant.analysis

import android.content.Context
import android.util.Log
import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.AnalysisSource
import com.diagpro.assistant.analysis.model.CauseProbability
import com.diagpro.assistant.analysis.model.Severity
import com.diagpro.assistant.util.Constants
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

// ═══════════════════════════════════════════════════════
//  AI Provider enum
// ═══════════════════════════════════════════════════════

enum class AiProvider { CLAUDE, OPENAI, LOCAL }

// ═══════════════════════════════════════════════════════
//  System prompt موحّد لكلا الـ AI
// ═══════════════════════════════════════════════════════

private fun buildSystemPrompt(vehicleHint: String = ""): String = """
أنت خبير تشخيص سيارات متخصص في أكواد OBD-II لجميع الماركات.
${if (vehicleHint.isNotBlank()) "السيارة المُفحوصة: $vehicleHint" else ""}

أجب بـ JSON فقط بدون أي نص إضافي أو markdown:
{
  "code": "كود العطل",
  "name_ar": "اسم العطل بالعربية",
  "description": "وصف فني مختصر وواضح",
  "causes": ["السبب الأول", "الثاني", "الثالث"],
  "probabilities": [
    {"cause": "السبب", "probability": 70, "case_count": 0},
    {"cause": "السبب", "probability": 20, "case_count": 0}
  ],
  "steps": ["خطوة 1", "خطوة 2", "خطوة 3"],
  "severity": "LOW | MEDIUM | HIGH | CRITICAL",
  "special_notes": "أي ملاحظة خاصة أو فارغة"
}

قواعد:
- severity: LOW أو MEDIUM أو HIGH أو CRITICAL فقط
- probabilities: رتّب الأسباب تنازليًا حسب احتمالية الحدوث
- الأكواد الخاصة بالمصنّع (P1xxx, P3xxx) حللها حسب أشهر ماركاتها
- لا تضف أي نص خارج JSON
""".trimIndent()

// ═══════════════════════════════════════════════════════
//  OkHttp client مشترك
// ═══════════════════════════════════════════════════════

private val httpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(Constants.API_TIMEOUT_SEC, TimeUnit.SECONDS)
        .readTimeout(Constants.API_TIMEOUT_SEC, TimeUnit.SECONDS)
        .build()
}
private val gson = Gson()

// ═══════════════════════════════════════════════════════
//  Claude Analyzer
// ═══════════════════════════════════════════════════════

object ClaudeAnalyzer {

    private const val TAG = "ClaudeAnalyzer"

    suspend fun analyze(code: String, apiKey: String, vehicleHint: String = ""): AnalysisResult =
        withContext(Dispatchers.IO) {
            val body = gson.toJson(mapOf(
                "model"      to "claude-sonnet-4-20250514",
                "max_tokens" to 1024,
                "system"     to buildSystemPrompt(vehicleHint),
                "messages"   to listOf(mapOf("role" to "user", "content" to "حلل: $code"))
            ))

            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("Content-Type", "application/json")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = httpClient.newCall(req).execute()
            val raw  = resp.body?.string() ?: throw Exception("استجابة فارغة")

            if (!resp.isSuccessful) {
                val err = gson.fromJson(raw, JsonObject::class.java)
                    .getAsJsonObject("error")?.get("message")?.asString ?: "HTTP ${resp.code}"
                throw Exception("Claude: $err")
            }

            val text = gson.fromJson(raw, JsonObject::class.java)
                .getAsJsonArray("content")?.get(0)?.asJsonObject
                ?.get("text")?.asString ?: throw Exception("لا محتوى")

            parseAiJson(cleanJson(text), code, AnalysisSource.AI_CLAUDE)
        }
}

// ═══════════════════════════════════════════════════════
//  OpenAI Analyzer
// ═══════════════════════════════════════════════════════

object OpenAiAnalyzer {

    suspend fun analyze(code: String, apiKey: String, vehicleHint: String = ""): AnalysisResult =
        withContext(Dispatchers.IO) {
            val body = gson.toJson(mapOf(
                "model"           to "gpt-4o",
                "max_tokens"      to 1024,
                "response_format" to mapOf("type" to "json_object"),
                "messages"        to listOf(
                    mapOf("role" to "system", "content" to buildSystemPrompt(vehicleHint)),
                    mapOf("role" to "user",   "content" to "حلل: $code")
                )
            ))

            val req = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = httpClient.newCall(req).execute()
            val raw  = resp.body?.string() ?: throw Exception("استجابة فارغة")

            if (!resp.isSuccessful) {
                val err = gson.fromJson(raw, JsonObject::class.java)
                    .getAsJsonObject("error")?.get("message")?.asString ?: "HTTP ${resp.code}"
                throw Exception("OpenAI: $err")
            }

            val text = gson.fromJson(raw, JsonObject::class.java)
                .getAsJsonArray("choices")?.get(0)?.asJsonObject
                ?.getAsJsonObject("message")
                ?.get("content")?.asString ?: throw Exception("لا محتوى")

            parseAiJson(cleanJson(text), code, AnalysisSource.AI_OPENAI)
        }
}

// ═══════════════════════════════════════════════════════
//  Parser موحّد لنتيجة AI
// ═══════════════════════════════════════════════════════

fun parseAiJson(jsonStr: String, fallbackCode: String, source: AnalysisSource): AnalysisResult {
    val j = gson.fromJson(jsonStr, JsonObject::class.java)

    fun arr(key: String): List<String> {
        val a = j.getAsJsonArray(key) ?: return emptyList()
        return (0 until a.size()).map { a[it].asString }
    }

    val probabilities = try {
        val pa = j.getAsJsonArray("probabilities") ?: return@try emptyList<CauseProbability>()
        (0 until pa.size()).map { i ->
            val o = pa[i].asJsonObject
            CauseProbability(
                cause       = o.get("cause")?.asString ?: "",
                probability = o.get("probability")?.asInt ?: 0,
                caseCount   = o.get("case_count")?.asInt ?: 0
            )
        }
    } catch (e: Exception) { emptyList() }

    val severityStr = j.get("severity")?.asString ?: "MEDIUM"
    val severity = try { Severity.valueOf(severityStr.uppercase()) } catch (e: Exception) { Severity.MEDIUM }

    return AnalysisResult(
        code          = j.get("code")?.asString ?: fallbackCode,
        nameAr        = j.get("name_ar")?.asString ?: "عطل غير محدد",
        description   = j.get("description")?.asString ?: "",
        causes        = arr("causes"),
        steps         = arr("steps"),
        severity      = severity,
        probabilities = probabilities,
        specialNotes  = j.get("special_notes")?.asString ?: "",
        isFound       = true,
        source        = source
    )
}

fun cleanJson(raw: String): String =
    raw.replace(Regex("```json\\s*"), "").replace(Regex("```\\s*"), "").trim()
