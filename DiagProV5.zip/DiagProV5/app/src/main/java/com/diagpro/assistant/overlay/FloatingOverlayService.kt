package com.diagpro.assistant.overlay

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.diagpro.assistant.DiagProApp
import com.diagpro.assistant.R
import com.diagpro.assistant.analysis.AnalysisRepository
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.data.local.CaseEntity
import com.diagpro.assistant.ui.MainActivity
import com.diagpro.assistant.util.Constants
import com.diagpro.assistant.util.runOnMain
import com.diagpro.assistant.util.showToast
import com.google.gson.Gson
import kotlinx.coroutines.*

class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_START          = "diagpro.START"
        const val ACTION_SHOW           = "diagpro.SHOW"
        const val ACTION_HIDE           = "diagpro.HIDE"
        const val ACTION_STOP           = "diagpro.STOP"
        const val ACTION_UPDATE_VEHICLE = "diagpro.UPDATE_VEHICLE"
        const val EXTRA_CODES           = "extra_codes"
        const val EXTRA_VEHICLE_JSON    = "extra_vehicle_json"
        private const val TAG           = "OverlayService"
    }

    private val scope      = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val gson       = Gson()
    private var state      : OverlayState = OverlayState.Hidden
    private var analyzeJob : Job? = null

    private lateinit var controller  : OverlayController
    private lateinit var analysisRepo: AnalysisRepository

    // ═══════════════════════════════════════════════
    //  دورة الحياة
    // ═══════════════════════════════════════════════

    override fun onCreate() {
        super.onCreate()
        analysisRepo = AnalysisRepository(applicationContext)

        controller = OverlayController(
            context           = this,
            onBubbleClick     = ::handleBubbleClick,
            onSaveCaseClick   = ::handleSaveCase,
            onMarkSolvedClick = ::handleMarkSolved,
            onReportClick     = ::handleOpenReport
        )
        controller.onChipSelected = { code -> triggerAnalysis(code) }

        startForeground(Constants.NOTIF_ID_OVERLAY, buildNotification())
        Log.d(TAG, "✅ FloatingOverlayService بدأت")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> { }
            ACTION_SHOW  -> {
                val codes = intent.getStringArrayListExtra(EXTRA_CODES) ?: return START_STICKY
                val vehicleJson = intent.getStringExtra(EXTRA_VEHICLE_JSON)
                val vehicle = vehicleJson?.let { gson.fromJson(it, VehicleInfo::class.java) }
                handleShowCodes(codes, vehicle)
            }
            ACTION_UPDATE_VEHICLE -> {
                val json = intent.getStringExtra(EXTRA_VEHICLE_JSON) ?: return START_STICKY
                val vehicle = gson.fromJson(json, VehicleInfo::class.java)
                handleVehicleUpdate(vehicle)
            }
            ACTION_HIDE  -> handleHide()
            ACTION_STOP  -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        controller.removeAll()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ═══════════════════════════════════════════════
    //  معالجة الأوامر
    // ═══════════════════════════════════════════════

    private fun handleShowCodes(codes: List<String>, vehicle: VehicleInfo?) {
        runOnMain {
            when (val s = state) {
                is OverlayState.Hidden -> {
                    state = OverlayState.BubbleOnly(codes, vehicle)
                    controller.showBubble(codes, vehicle)
                }
                is OverlayState.BubbleOnly -> {
                    if (codes != s.codes) {
                        state = OverlayState.BubbleOnly(codes, vehicle ?: s.vehicle)
                        controller.updateBubble(codes)
                    }
                }
                is OverlayState.DrawerLoading,
                is OverlayState.DrawerReady -> {
                    controller.updateBubble(codes)
                    // إذا اختلفت الأكواد أعد التحليل
                    val currentCode = when (s) {
                        is OverlayState.DrawerLoading -> s.selectedCode
                        is OverlayState.DrawerReady   -> s.selectedCode
                        else -> codes.firstOrNull() ?: return@runOnMain
                    }
                    if (!codes.contains(currentCode)) triggerAnalysis(codes.firstOrNull() ?: return@runOnMain)
                }
            }
        }
    }

    private fun handleVehicleUpdate(vehicle: VehicleInfo) {
        runOnMain {
            state = when (val s = state) {
                is OverlayState.BubbleOnly    -> s.copy(vehicle = vehicle)
                is OverlayState.DrawerLoading -> s.copy(vehicle = vehicle)
                is OverlayState.DrawerReady   -> s.copy(vehicle = vehicle)
                else -> s
            }
            controller.updateVehicleInDrawer(vehicle)
        }
    }

    private fun handleBubbleClick() {
        val (codes, vehicle) = when (val s = state) {
            is OverlayState.BubbleOnly -> Pair(s.codes, s.vehicle)
            else -> return
        }
        controller.openDrawer(codes, vehicle)
        triggerAnalysis(codes.firstOrNull() ?: return)
    }

    private fun handleHide() {
        runOnMain {
            controller.hideBubble()
            state = OverlayState.Hidden
            analyzeJob?.cancel()
        }
    }

    // ═══════════════════════════════════════════════
    //  التحليل
    // ═══════════════════════════════════════════════

    private fun triggerAnalysis(code: String) {
        val (codes, vehicle) = when (val s = state) {
            is OverlayState.BubbleOnly    -> Pair(s.codes, s.vehicle)
            is OverlayState.DrawerLoading -> Pair(s.codes, s.vehicle)
            is OverlayState.DrawerReady   -> Pair(s.codes, s.vehicle)
            else -> return
        }

        state = OverlayState.DrawerLoading(codes, code, vehicle)
        if (!controller.isDrawerOpen()) controller.openDrawer(codes, vehicle)
        controller.showLoading()

        analyzeJob?.cancel()
        analyzeJob = scope.launch {
            val analysis = analysisRepo.analyze(code, vehicle)
            state = OverlayState.DrawerReady(codes, code, analysis, vehicle)
            controller.showAnalysis(analysis, null)
        }
    }

    // ═══════════════════════════════════════════════
    //  حفظ الحالة
    // ═══════════════════════════════════════════════

    private fun handleSaveCase(codes: List<String>, primaryCode: String, notes: String) {
        val s = state as? OverlayState.DrawerReady ?: return
        scope.launch {
            val db = (application as DiagProApp).database
            val entity = CaseEntity(
                primaryCode  = primaryCode,
                dtcCodes     = codes,
                vehicleMake  = s.vehicle?.make ?: "",
                vehicleModel = s.vehicle?.model ?: "",
                vehicleYear  = s.vehicle?.year ?: 0,
                faultNameAr  = s.analysis.nameAr,
                description  = s.analysis.description,
                causes       = s.analysis.causes,
                steps        = s.analysis.steps,
                severity     = s.analysis.severity.name,
                techNotes    = notes,
                aiSource     = s.analysis.source.name
            )
            val savedId = db.caseDao().insert(entity)
            state = s.copy(savedCaseId = savedId)
            withContext(Dispatchers.Main) {
                controller.onCaseSaved(savedId)
                showToast("✅ تم حفظ الحالة")
            }
        }
    }

    private fun handleMarkSolved(caseId: Long?) {
        val id = caseId ?: run { showToast("احفظ الحالة أولًا"); return }
        scope.launch {
            val db = (application as DiagProApp).database
            db.caseDao().markSolved(id)
            withContext(Dispatchers.Main) {
                controller.onSolvedConfirmed()
                showToast("✅ تم تسجيل الحالة كمحلولة")
            }
        }
    }

    private fun handleOpenReport() {
        val s = state as? OverlayState.DrawerReady
        val vehicle = s?.vehicle
        val codes   = s?.codes ?: emptyList()
        val intent = Intent(this, MainActivity::class.java).apply {
            action  = MainActivity.ACTION_OPEN_REPORT
            flags   = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putStringArrayListExtra(MainActivity.EXTRA_CODES_FOR_REPORT, ArrayList(codes))
            vehicle?.let {
                putExtra(MainActivity.EXTRA_VEHICLE_MAKE,  it.make)
                putExtra(MainActivity.EXTRA_VEHICLE_MODEL, it.model)
                putExtra(MainActivity.EXTRA_VEHICLE_YEAR,  it.year)
                putExtra(MainActivity.EXTRA_VEHICLE_VIN,   it.vin)
            }
        }
        startActivity(intent)
    }

    // ═══════════════════════════════════════════════
    //  Foreground Notification
    // ═══════════════════════════════════════════════

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                Constants.CHANNEL_ID_OVERLAY,
                "DiagPro Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_STOP },
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, Constants.CHANNEL_ID_OVERLAY)
            .setContentTitle("DiagPro Assistant")
            .setContentText("جاهز لمراقبة X-Diag")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_delete, "إيقاف", stopPi)
            .setOngoing(true).setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
}
