package com.diagpro.assistant.ui

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.diagpro.assistant.DiagProApp
import com.diagpro.assistant.R
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.cloud.CloudResult
import com.diagpro.assistant.cloud.DiagProCloudClient
import com.diagpro.assistant.data.local.ReportEntity
import com.diagpro.assistant.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * شاشة تقرير الصيانة الكاملة
 *
 * تسحب تلقائياً:
 * - أكواد العطل من X-Diag
 * - بيانات السيارة (إذا كُشفت)
 *
 * ويكتب الفني:
 * - ما تم إصلاحه
 * - القطع المستبدلة
 * - الأعطال بعد الإصلاح
 * - ثم يرسل لـ DiagPro Cloud
 */
class RepairReportActivity : AppCompatActivity() {

    // بيانات واردة من الـ Overlay
    private var preCodes   = listOf<String>()
    private var vehicleInfo: VehicleInfo? = null
    private var reportId   = UUID.randomUUID().toString()

    // Views — معلومات السيارة
    private lateinit var tvVehicleAuto    : TextView
    private lateinit var layoutManualEntry: LinearLayout
    private lateinit var etMake           : EditText
    private lateinit var etModel          : EditText
    private lateinit var spinnerYear      : Spinner
    private lateinit var etVin            : EditText
    private lateinit var etMileage        : EditText
    private lateinit var btnToggleManual  : Button

    // Views — قبل الإصلاح
    private lateinit var tvPreCodes       : TextView

    // Views — الإصلاح
    private lateinit var etDiagnosis      : EditText
    private lateinit var etPartsReplaced  : EditText
    private lateinit var etLaborDesc      : EditText
    private lateinit var etTechNotes      : EditText

    // Views — بعد الإصلاح
    private lateinit var etPostCodes      : EditText
    private lateinit var switchSolved     : Switch
    private lateinit var switchRoadTest   : Switch

    // Views — AI
    private lateinit var tvAiSuggested    : TextView
    private lateinit var switchAiCorrect  : Switch
    private lateinit var layoutAiCorrect  : LinearLayout

    // Views — إجراءات
    private lateinit var btnSaveDraft     : Button
    private lateinit var btnSendCloud     : Button
    private lateinit var progressSend     : ProgressBar
    private lateinit var tvSendStatus     : TextView

    private var manualEntryVisible = false

    // ═══════════════════════════════════════════════
    //  دورة الحياة
    // ═══════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repair_report)

        bindViews()
        loadIntentData()
        setupYearSpinner()
        setupListeners()
        populatePreData()
    }

    // ═══════════════════════════════════════════════
    //  ربط الـ Views
    // ═══════════════════════════════════════════════

    private fun bindViews() {
        tvVehicleAuto     = findViewById(R.id.tvVehicleAuto)
        layoutManualEntry = findViewById(R.id.layoutManualEntry)
        etMake            = findViewById(R.id.etMake)
        etModel           = findViewById(R.id.etModel)
        spinnerYear       = findViewById(R.id.spinnerYear)
        etVin             = findViewById(R.id.etVin)
        etMileage         = findViewById(R.id.etMileage)
        btnToggleManual   = findViewById(R.id.btnToggleManual)
        tvPreCodes        = findViewById(R.id.tvPreCodes)
        etDiagnosis       = findViewById(R.id.etDiagnosis)
        etPartsReplaced   = findViewById(R.id.etPartsReplaced)
        etLaborDesc       = findViewById(R.id.etLaborDesc)
        etTechNotes       = findViewById(R.id.etTechNotes)
        etPostCodes       = findViewById(R.id.etPostCodes)
        switchSolved      = findViewById(R.id.switchSolved)
        switchRoadTest    = findViewById(R.id.switchRoadTest)
        tvAiSuggested     = findViewById(R.id.tvAiSuggested)
        switchAiCorrect   = findViewById(R.id.switchAiCorrect)
        layoutAiCorrect   = findViewById(R.id.layoutAiCorrect)
        btnSaveDraft      = findViewById(R.id.btnSaveDraft)
        btnSendCloud      = findViewById(R.id.btnSendCloud)
        progressSend      = findViewById(R.id.progressSend)
        tvSendStatus      = findViewById(R.id.tvSendStatus)

        supportActionBar?.apply { title = "📋 تقرير الصيانة"; setDisplayHomeAsUpEnabled(true) }
    }

    // ═══════════════════════════════════════════════
    //  تحميل بيانات الـ Intent
    // ═══════════════════════════════════════════════

    private fun loadIntentData() {
        preCodes = intent.getStringArrayListExtra(EXTRA_PRE_CODES)?.toList() ?: emptyList()

        val make  = intent.getStringExtra(EXTRA_VEHICLE_MAKE) ?: ""
        val model = intent.getStringExtra(EXTRA_VEHICLE_MODEL) ?: ""
        val year  = intent.getIntExtra(EXTRA_VEHICLE_YEAR, 0)
        val vin   = intent.getStringExtra(EXTRA_VEHICLE_VIN) ?: ""

        if (make.isNotBlank() || model.isNotBlank() || year > 0) {
            vehicleInfo = VehicleInfo(make, model, year, vin,
                source = VehicleInfo.VehicleSource.AUTO_DETECTED)
        }
    }

    // ═══════════════════════════════════════════════
    //  تعبئة البيانات الأولية
    // ═══════════════════════════════════════════════

    private fun populatePreData() {
        // أكواد قبل الإصلاح
        tvPreCodes.text = if (preCodes.isNotEmpty())
            preCodes.joinToString(" | ")
        else "لا توجد أكواد مُسجَّلة"

        // بيانات السيارة
        val v = vehicleInfo
        if (v != null && v.isValid()) {
            tvVehicleAuto.text = "🚗 ${v.displayName()}"
            if (v.vin.isNotBlank()) etVin.setText(v.vin)
            // اختر السنة في الـ Spinner
            val yearIndex = getYearList().indexOf(v.year.toString())
            if (yearIndex >= 0) spinnerYear.setSelection(yearIndex)
            etMake.setText(v.make)
            etModel.setText(v.model)
        } else {
            tvVehicleAuto.text = "⚠️ لم يُكتشف تلقائياً — أدخل يدوياً"
            // افتح اليدوي تلقائياً
            showManualEntry()
        }

        // وقت التقرير
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        tvSendStatus.text = "🕐 ${sdf.format(Date())}"
    }

    private fun setupYearSpinner() {
        val years = getYearList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, years)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerYear.adapter = adapter
        // اختر السنة الحالية افتراضياً
        spinnerYear.setSelection(years.indexOf(Calendar.getInstance().get(Calendar.YEAR).toString()).coerceAtLeast(0))
    }

    private fun getYearList(): List<String> {
        val current = Calendar.getInstance().get(Calendar.YEAR)
        return (current downTo 1990).map { it.toString() }
    }

    // ═══════════════════════════════════════════════
    //  المستمعون
    // ═══════════════════════════════════════════════

    private fun setupListeners() {
        btnToggleManual.setOnClickListener {
            if (manualEntryVisible) hideManualEntry() else showManualEntry()
        }

        btnSaveDraft.setOnClickListener { saveReport(sendToCloud = false) }

        btnSendCloud.setOnClickListener {
            if (!isCloudEnabled()) {
                showToast("فعّل DiagPro Cloud من الإعدادات أولًا", long = true)
                return@setOnClickListener
            }
            if (!isOnline()) {
                showToast("لا يوجد اتصال بالإنترنت", long = true)
                return@setOnClickListener
            }
            saveReport(sendToCloud = true)
        }
    }

    private fun showManualEntry() {
        manualEntryVisible = true
        layoutManualEntry.visibility = View.VISIBLE
        btnToggleManual.text = "▲ إخفاء إدخال يدوي"
    }

    private fun hideManualEntry() {
        manualEntryVisible = false
        layoutManualEntry.visibility = View.GONE
        btnToggleManual.text = "✏️ تعديل يدوي"
    }

    // ═══════════════════════════════════════════════
    //  حفظ وإرسال التقرير
    // ═══════════════════════════════════════════════

    private fun saveReport(sendToCloud: Boolean) {
        val finalVehicle = buildFinalVehicle()

        if (etDiagnosis.text.isBlank()) {
            showToast("⚠️ أدخل التشخيص الفعلي على الأقل")
            return
        }

        val postCodesText = etPostCodes.text.toString().trim()
        val postCodes = if (postCodesText.isBlank()) emptyList()
        else postCodesText.split(Regex("[,،\\s]+")).filter { it.isNotBlank() }

        val entity = ReportEntity(
            reportId         = reportId,
            workshopId       = getWorkshopId(),
            technicianName   = getTechnicianName(),
            vehicleMake      = finalVehicle.make,
            vehicleModel     = finalVehicle.model,
            vehicleYear      = finalVehicle.year,
            vehicleVin       = finalVehicle.vin,
            vehicleMileage   = etMileage.text.toString().toIntOrNull() ?: 0,
            vehicleSource    = finalVehicle.source.name,
            preRepairCodes   = preCodes,
            diagnosis        = etDiagnosis.text.toString().trim(),
            partsReplaced    = etPartsReplaced.text.toString()
                .split(Regex("[,،\n]+")).map { it.trim() }.filter { it.isNotBlank() },
            laborDescription = etLaborDesc.text.toString().trim(),
            technicianNotes  = etTechNotes.text.toString().trim(),
            postRepairCodes  = postCodes,
            confirmedSolved  = switchSolved.isChecked,
            roadTestDone     = switchRoadTest.isChecked,
            aiSuggested      = tvAiSuggested.text.toString(),
            aiWasCorrect     = if (layoutAiCorrect.visibility == View.VISIBLE) switchAiCorrect.isChecked else null,
            status           = if (sendToCloud) "COMPLETED" else "DRAFT"
        )

        lifecycleScope.launch {
            // 1. حفظ محلي دائماً
            val db = (application as DiagProApp).database
            db.reportDao().insert(entity)

            if (!sendToCloud) {
                showToast("✅ تم حفظ التقرير كمسودة")
                finish()
                return@launch
            }

            // 2. إرسال للـ Cloud
            withContext(Dispatchers.Main) {
                progressSend.visibility = View.VISIBLE
                btnSendCloud.isEnabled  = false
                tvSendStatus.text       = "⏳ جاري الإرسال..."
            }

            val client = DiagProCloudClient(getCloudUrl(), getCloudKey(), getWorkshopId())
            val result = client.sendRepairReport(entity)

            withContext(Dispatchers.Main) {
                progressSend.visibility = View.GONE
                btnSendCloud.isEnabled  = true
                when (result) {
                    is CloudResult.Success -> {
                        db.reportDao().markSynced(reportId)
                        tvSendStatus.text = "✅ تم الإرسال بنجاح — ${result.data}"
                        showToast("📡 تم إرسال التقرير لـ DiagPro Cloud", long = true)
                        finish()
                    }
                    is CloudResult.Error -> {
                        tvSendStatus.text = "❌ فشل: ${result.message}"
                        showToast("تم الحفظ محلياً — فشل الإرسال: ${result.message}", long = true)
                    }
                }
            }
        }
    }

    private fun buildFinalVehicle(): VehicleInfo {
        // إذا كان الإدخال اليدوي مرئياً، استخدمه
        return if (manualEntryVisible || vehicleInfo == null || !vehicleInfo!!.isValid()) {
            VehicleInfo(
                make   = etMake.text.toString().trim(),
                model  = etModel.text.toString().trim(),
                year   = spinnerYear.selectedItem?.toString()?.toIntOrNull() ?: 0,
                vin    = etVin.text.toString().trim(),
                source = VehicleInfo.VehicleSource.MANUAL_ENTRY
            )
        } else {
            vehicleInfo!!.copy(
                vin = etVin.text.toString().trim().ifBlank { vehicleInfo!!.vin }
            )
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    companion object {
        const val EXTRA_PRE_CODES    = "extra_pre_codes"
        const val EXTRA_VEHICLE_MAKE = "extra_vehicle_make"
        const val EXTRA_VEHICLE_MODEL= "extra_vehicle_model"
        const val EXTRA_VEHICLE_YEAR = "extra_vehicle_year"
        const val EXTRA_VEHICLE_VIN  = "extra_vehicle_vin"
    }
}
