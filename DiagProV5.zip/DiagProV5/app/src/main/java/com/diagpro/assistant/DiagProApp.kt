package com.diagpro.assistant

import android.app.Application
import android.util.Log
import com.diagpro.assistant.analysis.LocalAnalyzer
import com.diagpro.assistant.data.local.AppDatabase

class DiagProApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.get(this) }

    var localDbSize = 0
        private set

    override fun onCreate() {
        super.onCreate()
        Thread {
            localDbSize = LocalAnalyzer(applicationContext).size()
            Log.d("DiagProApp", "✅ V5 جاهز — قاعدة DTC: $localDbSize كود")
        }.start()
    }
}
