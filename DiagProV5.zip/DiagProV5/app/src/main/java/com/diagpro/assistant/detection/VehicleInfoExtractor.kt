package com.diagpro.assistant.detection

import android.util.Log
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.util.Constants

/**
 * يستخرج معلومات السيارة من النص الظاهر في X-Diag
 *
 * X-Diag يعرض المعلومات بأحد الشكلين:
 * الشكل 1: "Toyota Camry 2019"
 * الشكل 2: "VIN: 1HGBH41JXMN109186"
 *
 * الأولوية: VIN أولاً ← Make/Model/Year ← لا شيء
 */
object VehicleInfoExtractor {

    private const val TAG = "VehicleExtractor"

    // ماركات السيارات الشائعة للمطابقة
    private val KNOWN_MAKES = listOf(
        "Toyota", "Lexus", "Nissan", "Infiniti",
        "Honda", "Acura", "Ford", "GMC", "Chevrolet", "Buick", "Cadillac",
        "Dodge", "Jeep", "RAM", "Chrysler",
        "BMW", "Mercedes", "Audi", "Volkswagen", "Porsche",
        "Hyundai", "Kia", "Genesis",
        "Mitsubishi", "Mazda", "Subaru", "Suzuki",
        "Land Rover", "Range Rover", "Jaguar",
        "Volvo", "Peugeot", "Renault",
        "Isuzu", "Daihatsu",
        // اسماء عربية محتملة
        "تويوتا", "نيسان", "هوندا", "فورد", "شيفروليه"
    )

    /**
     * الدالة الرئيسية — تحاول استخراج بيانات السيارة
     * @return VehicleInfo مع source=AUTO_DETECTED إذا نجح، أو null
     */
    fun extract(screenText: String): VehicleInfo? {
        if (screenText.isBlank()) return null

        // 1. حاول VIN أولاً
        val vin = extractVin(screenText)

        // 2. حاول Make/Model/Year
        val makeModelYear = extractMakeModelYear(screenText)

        return when {
            vin != null && makeModelYear != null -> {
                makeModelYear.copy(vin = vin)
            }
            vin != null -> {
                VehicleInfo(vin = vin, source = VehicleInfo.VehicleSource.AUTO_DETECTED)
            }
            makeModelYear != null -> makeModelYear
            else -> {
                Log.d(TAG, "⚠️ لم يتم كشف بيانات السيارة تلقائياً")
                null
            }
        }
    }

    private fun extractVin(text: String): String? {
        val match = Constants.VIN_REGEX.find(text) ?: return null
        val vin = match.value
        // تحقق أساسي من صحة VIN
        return if (vin.length == 17 && isValidVin(vin)) {
            Log.d(TAG, "✅ VIN مُكتشف: $vin")
            vin
        } else null
    }

    private fun extractMakeModelYear(text: String): VehicleInfo? {
        val year = Constants.VEHICLE_YEAR_REGEX.find(text)?.value?.toIntOrNull()

        // ابحث عن أي ماركة معروفة في النص
        val foundMake = KNOWN_MAKES.firstOrNull { make ->
            text.contains(make, ignoreCase = true)
        }

        return if (foundMake != null && year != null) {
            // حاول استخراج الموديل (الكلمة بعد الماركة)
            val makeIndex = text.indexOf(foundMake, ignoreCase = true)
            val afterMake = text.substring(makeIndex + foundMake.length).trim()
            val modelCandidate = afterMake.split(Regex("\\s+")).firstOrNull {
                it.isNotBlank() && it != year.toString() && it.length > 1
            } ?: ""

            Log.d(TAG, "✅ سيارة مُكتشفة: $foundMake $modelCandidate $year")
            VehicleInfo(
                make   = foundMake,
                model  = modelCandidate,
                year   = year,
                source = VehicleInfo.VehicleSource.AUTO_DETECTED
            )
        } else if (year != null) {
            VehicleInfo(year = year, source = VehicleInfo.VehicleSource.AUTO_DETECTED)
        } else null
    }

    private fun isValidVin(vin: String): Boolean {
        // لا يحتوي على I, O, Q
        return !vin.any { it == 'I' || it == 'O' || it == 'Q' }
    }
}
