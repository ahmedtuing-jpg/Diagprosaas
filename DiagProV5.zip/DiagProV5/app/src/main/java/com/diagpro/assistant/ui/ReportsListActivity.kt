package com.diagpro.assistant.ui

import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diagpro.assistant.DiagProApp
import com.diagpro.assistant.R
import com.diagpro.assistant.data.local.ReportEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ReportsListActivity : AppCompatActivity() {

    private lateinit var rv    : RecyclerView
    private lateinit var tvEmpty: TextView
    private val adapter = ReportAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports_list)
        supportActionBar?.apply { title = "📋 تقارير الصيانة"; setDisplayHomeAsUpEnabled(true) }

        rv     = findViewById(R.id.rvReports)
        tvEmpty= findViewById(R.id.tvEmpty)

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        lifecycleScope.launch {
            val db = (application as DiagProApp).database
            db.reportDao().getAll().collectLatest { list ->
                adapter.submitList(list)
                tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                rv.visibility      = if (list.isEmpty()) View.GONE   else View.VISIBLE
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ── Adapter ──────────────────────────────────────────

class ReportAdapter : RecyclerView.Adapter<ReportAdapter.VH>() {

    private var items = listOf<ReportEntity>()
    private val sdf   = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvVehicle  : TextView = v.findViewById(R.id.tvReportVehicle)
        val tvCodes    : TextView = v.findViewById(R.id.tvReportCodes)
        val tvDate     : TextView = v.findViewById(R.id.tvReportDate)
        val tvStatus   : TextView = v.findViewById(R.id.tvReportStatus)
        val tvDiagnosis: TextView = v.findViewById(R.id.tvReportDiagnosis)
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_report, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = items[pos]
        val vehicle = buildString {
            if (r.vehicleMake.isNotBlank())  append(r.vehicleMake)
            if (r.vehicleModel.isNotBlank()) append(" ${r.vehicleModel}")
            if (r.vehicleYear > 0)           append(" ${r.vehicleYear}")
        }.trim().ifBlank { "سيارة غير محددة" }

        h.tvVehicle.text   = "🚗 $vehicle"
        h.tvCodes.text     = r.preRepairCodes.joinToString(" | ").ifBlank { "لا أكواد" }
        h.tvDate.text      = sdf.format(Date(r.createdAt))
        h.tvDiagnosis.text = r.diagnosis.ifBlank { "لم يُكتب التشخيص" }
        h.tvStatus.text    = when (r.status) {
            "SYNCED"    -> "📡 مُرسَل"
            "COMPLETED" -> "✅ مكتمل"
            else        -> "📝 مسودة"
        }
        val statusColor = when (r.status) {
            "SYNCED"    -> 0xFF4CAF50.toInt()
            "COMPLETED" -> 0xFFFF9800.toInt()
            else        -> 0xFF9E9E9E.toInt()
        }
        h.tvStatus.setTextColor(statusColor)
    }

    override fun getItemCount() = items.size

    fun submitList(list: List<ReportEntity>) {
        items = list
        notifyDataSetChanged()
    }
}
