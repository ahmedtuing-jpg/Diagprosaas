package com.diagpro.assistant.report

import com.diagpro.assistant.analysis.model.VehicleInfo

// ═══════════════════════════════════════════════════════
//  تقرير الصيانة الكامل — يُرسَل لـ DiagPro Cloud
// ═══════════════════════════════════════════════════════

data class RepairReport(

    val reportId         : String = java.util.UUID.randomUUID().toString(),

    // معلومات الورشة
    val workshopId       : String = "",
    val technicianName   : String = "",

    // الطابع الزمني
    val createdAt        : Long = System.currentTimeMillis(),
    val updatedAt        : Long = System.currentTimeMillis(),

    // معلومات السيارة
    val vehicle          : VehicleInfo = VehicleInfo(),

    // الأعطال قبل الإصلاح
    val preRepairCodes   : List<String> = emptyList(),
    val preRepairSnapshot: Map<String, String> = emptyMap(),  // Live Data key/value

    // ما تم إصلاحه — يكتبه الفني
    val diagnosis        : String = "",        // التشخيص الفعلي
    val partsReplaced    : List<String> = emptyList(),
    val laborDescription : String = "",        // وصف العمل المنجز
    val technicianNotes  : String = "",

    // الأعطال بعد الإصلاح
    val postRepairCodes  : List<String> = emptyList(),
    val confirmedSolved  : Boolean = false,
    val roadTestDone     : Boolean = false,

    // نتيجة AI
    val aiSuggested      : String = "",        // ما اقترحه AI
    val aiWasCorrect     : Boolean? = null,    // هل كان صحيحاً؟

    // حالة الإرسال
    val status           : ReportStatus = ReportStatus.DRAFT,
    val isSyncedToCloud  : Boolean = false
)

enum class ReportStatus {
    DRAFT,          // مسودة — لم تكتمل بعد
    COMPLETED,      // مكتمل — جاهز للإرسال
    SYNCED          // تم الإرسال لـ DiagPro Cloud
}

// مكونات التقرير المُستخدمة في نموذج تقرير الصيانة
data class PartEntry(
    val name     : String,
    val quantity : Int = 1
)
