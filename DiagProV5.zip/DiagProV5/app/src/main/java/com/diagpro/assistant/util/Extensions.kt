package com.diagpro.assistant.util

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.widget.Toast

fun Context.dpToPx(dp: Int): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()

fun Context.showToast(msg: String, long: Boolean = false) =
    Handler(Looper.getMainLooper()).post {
        Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

fun Context.prefs(): SharedPreferences =
    getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

fun Context.isOnline(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    return cm.activeNetworkInfo?.isConnectedOrConnecting == true
}

fun Context.isCloudEnabled()  = prefs().getBoolean(Constants.PREF_USE_CLOUD, false)
fun Context.getCloudUrl()     = prefs().getString(Constants.PREF_CLOUD_URL, Constants.DEFAULT_CLOUD_URL) ?: Constants.DEFAULT_CLOUD_URL
fun Context.getCloudKey()     = prefs().getString(Constants.PREF_CLOUD_KEY, "") ?: ""
fun Context.getWorkshopId()   = prefs().getString(Constants.PREF_WORKSHOP_ID, "workshop_default") ?: "workshop_default"
fun Context.getTechnicianName() = prefs().getString(Constants.PREF_TECHNICIAN_NAME, "فني") ?: "فني"

fun runOnMain(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) block()
    else Handler(Looper.getMainLooper()).post(block)
}
