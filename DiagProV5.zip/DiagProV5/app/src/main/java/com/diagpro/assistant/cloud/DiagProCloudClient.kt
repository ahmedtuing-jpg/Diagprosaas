package com.diagpro.assistant.cloud

import android.util.Log
import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.AnalysisSource
import com.diagpro.assistant.analysis.model.CauseProbability
import com.diagpro.assistant.analysis.model.Severity
import com.diagpro.assistant.analysis.cleanJson
import com.diagpro.assistant.data.local.ReportEntity
import com.diagpro.assistant.util.Constants
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit

// ═══════════════════════════════════════════════════════
//  Result wrapper
// ═══════════════════════════════════════════════════════

sealed class CloudResult<out T> {
    data class Success<T>(val data: T) : CloudResult<T>()
    data class Error(val message: String) : CloudResult<Nothing>()
}

// ═══════════════════════════════════════════════════════
//  DiagPro Cloud API Client
//  يمثّل الطبقة الثالثة: البيانات المُجمَّعة من ورش متعددة
// ═══════════════════════════════════════════════════════

class DiagProCloudClient(
    private val baseUrl   : String,
    private val apiKey    : String,
    private val workshopId: String
) {
    private val TAG = "DiagProCloud"
    private val gson = Gson()

    private val client: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        OkHttpClient.Builder()
            .connectTimeout(Constants.API_TIMEOUT_SEC, TimeUnit.SECONDS)
            .readTimeout(Constants.API_TIMEOUT_SEC, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $apiKey")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("X-Workshop-ID", workshopId)
                    .addHeader("X-App-Version", "5.0.0")
                    .build()
                chain.proceed(req)
            }.build()
    }

    // ═══════════════════════════════════════════════════
    //  تحليل الكود عبر DiagPro Cloud (بيانات مجمّعة)
    // ═══════════════════════════════════════════════════

    suspend fun analyze(
        code       : String,
        vehicleMake: String = "",
        vehicleModel: String = "",
        vehicleYear: Int = 0
    ): CloudResult<AnalysisResult> = withContext(Dispatchers.IO) {
        try {
            val payload = gson.toJson(mapOf(
                "code"    to code,
                "vehicle" to mapOf(
                    "make"  to vehicleMake,
                    "model" to vehicleModel,
                    "year"  to vehicleYear
                )
            ))
            val req = Request.Builder()
                .url("$baseUrl${Constants.ENDPOINT_ANALYZE}")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = client.newCall(req).execute()
            val body = resp.body?.string()

            if (!resp.isSuccessful || body.isNullOrBlank()) {
                return@withContext CloudResult.Error("HTTP ${resp.code}")
            }

            val r = gson.fromJson(body, CloudAnalysisResponse::class.java)
            CloudResult.Success(r.toAnalysisResult())

        } catch (e: Exception) {
            Log.e(TAG, "❌ Cloud analyze failed: ${e.message}")
            CloudResult.Error(e.message ?: "خطأ في الاتصال")
        }
    }

    // ═══════════════════════════════════════════════════
    //  إرسال تقرير الصيانة → يُغذّي قاعدة بيانات DiagPro
    // ═══════════════════════════════════════════════════

    suspend fun sendRepairReport(report: ReportEntity): CloudResult<String> =
        withContext(Dispatchers.IO) {
            try {
                val payload = gson.toJson(buildReportPayload(report))
                val req = Request.Builder()
                    .url("$baseUrl${Constants.ENDPOINT_SAVE_REPORT}")
                    .post(payload.toRequestBody("application/json".toMediaType()))
                    .build()

                val resp = client.newCall(req).execute()
                val body = resp.body?.string()

                if (resp.isSuccessful) {
                    val id = try {
                        gson.fromJson(body, JsonObject::class.java).get("report_id")?.asString ?: report.reportId
                    } catch (e: Exception) { report.reportId }
                    Log.d(TAG, "✅ تقرير أُرسل: $id")
                    CloudResult.Success(id)
                } else {
                    CloudResult.Error("HTTP ${resp.code}: ${resp.message}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Send report failed: ${e.message}")
                CloudResult.Error(e.message ?: "خطأ في الإرسال")
            }
        }

    // ═══════════════════════════════════════════════════
    //  إحصائيات الورشة
    // ═══════════════════════════════════════════════════

    suspend fun getWorkshopStats(): CloudResult<WorkshopStats> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$baseUrl${Constants.ENDPOINT_WORKSHOP_STATS}")
                .get().build()
            val resp = client.newCall(req).execute()
            val body = resp.body?.string()
            if (resp.isSuccessful && !body.isNullOrBlank()) {
                val stats = gson.fromJson(body, WorkshopStats::class.java)
                CloudResult.Success(stats)
            } else CloudResult.Error("HTTP ${resp.code}")
        } catch (e: Exception) {
            CloudResult.Error(e.message ?: "خطأ")
        }
    }

    // ═══════════════════════════════════════════════════
    //  بناء payload التقرير
    // ═══════════════════════════════════════════════════

    private fun buildReportPayload(r: ReportEntity): Map<String, Any> = mapOf(
        "report_id"    to r.reportId,
        "workshop_id"  to r.workshopId,
        "technician"   to r.technicianName,
        "created_at"   to r.createdAt,
        "vehicle"      to mapOf(
            "make"     to r.vehicleMake,
            "model"    to r.vehicleModel,
            "year"     to r.vehicleYear,
            "vin"      to r.vehicleVin,
            "mileage"  to r.vehicleMileage
        ),
        "pre_repair"   to mapOf(
            "codes"    to r.preRepairCodes,
            "live_data" to r.preRepairSnapshot
        ),
        "repair"       to mapOf(
            "diagnosis"  to r.diagnosis,
            "parts"      to r.partsReplaced,
            "labor"      to r.laborDescription,
            "notes"      to r.technicianNotes
        ),
        "post_repair"  to mapOf(
            "codes"          to r.postRepairCodes,
            "confirmed_solved" to r.confirmedSolved,
            "road_test"      to r.roadTestDone
        ),
        "ai_context"   to mapOf(
            "ai_suggested"   to r.aiSuggested,
            "ai_was_correct" to r.aiWasCorrect
        )
    )

    // ═══════════════════════════════════════════════════
    //  نماذج الاستجابة
    // ═══════════════════════════════════════════════════

    data class CloudAnalysisResponse(
        @SerializedName("code")          val code         : String,
        @SerializedName("name_ar")       val nameAr       : String,
        @SerializedName("description")   val description  : String,
        @SerializedName("causes")        val causes       : List<String>,
        @SerializedName("steps")         val steps        : List<String>,
        @SerializedName("severity")      val severity     : String,
        @SerializedName("probabilities") val probabilities: List<ProbabilityItem> = emptyList(),
        @SerializedName("special_notes") val specialNotes : String = ""
    ) {
        fun toAnalysisResult() = AnalysisResult(
            code          = code,
            nameAr        = nameAr,
            description   = description,
            causes        = causes,
            steps         = steps,
            severity      = try { Severity.valueOf(severity.uppercase()) } catch (e: Exception) { Severity.MEDIUM },
            probabilities = probabilities.map { CauseProbability(it.cause, it.probability, it.caseCount) },
            specialNotes  = specialNotes,
            isFound       = true,
            source        = AnalysisSource.DIAGPRO_CLOUD
        )
    }

    data class ProbabilityItem(
        @SerializedName("cause")      val cause      : String,
        @SerializedName("probability") val probability: Int,
        @SerializedName("case_count") val caseCount  : Int = 0
    )

    data class WorkshopStats(
        @SerializedName("total_reports")  val totalReports : Int = 0,
        @SerializedName("solved_cases")   val solvedCases  : Int = 0,
        @SerializedName("top_codes")      val topCodes     : List<String> = emptyList()
    )
}
