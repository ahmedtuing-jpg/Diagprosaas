package com.diagpro.assistant.analysis.model

// ═══════════════════════════════════════════════════════
//  نتيجة تحليل كود العطل — تُستخدم من كل المحللات
// ═══════════════════════════════════════════════════════

data class AnalysisResult(
    val code          : String,
    val nameAr        : String,
    val description   : String,
    val causes        : List<String>,
    val steps         : List<String>,
    val severity      : Severity,
    val probabilities : List<CauseProbability> = emptyList(),  // نسب الأسباب المحتملة
    val specialNotes  : String = "",
    val isFound       : Boolean = true,
    val source        : AnalysisSource = AnalysisSource.LOCAL,
    val timestamp     : Long = System.currentTimeMillis()
)

// نسبة احتمالية كل سبب — يُغذَّى من بيانات DiagPro Cloud
data class CauseProbability(
    val cause       : String,
    val probability : Int,       // 0-100
    val caseCount   : Int = 0    // عدد الحالات التي بني عليها الاحتمال
)

enum class Severity(val labelAr: String, val colorHex: String) {
    LOW     ("منخفض — للمتابعة",          "#4CAF50"),
    MEDIUM  ("متوسط — صيانة قريبة",       "#FF9800"),
    HIGH    ("عالٍ — إصلاح فوري",         "#F44336"),
    CRITICAL("حرج — أوقف السيارة فورًا",  "#9C27B0")
}

enum class AnalysisSource { LOCAL, AI_CLAUDE, AI_OPENAI, DIAGPRO_CLOUD }

// ═══════════════════════════════════════════════════════
//  معلومات السيارة
// ═══════════════════════════════════════════════════════

data class VehicleInfo(
    val make    : String = "",
    val model   : String = "",
    val year    : Int    = 0,
    val vin     : String = "",
    val mileage : Int    = 0,
    val source  : VehicleSource = VehicleSource.MANUAL
) {
    enum class VehicleSource { AUTO_DETECTED, MANUAL_ENTRY }

    fun isValid()    = make.isNotBlank() && model.isNotBlank() && year > 1980
    fun displayName() = buildString {
        if (make.isNotBlank()) append(make)
        if (model.isNotBlank()) append(" $model")
        if (year > 0) append(" $year")
    }.trim()
}

// ═══════════════════════════════════════════════════════
//  كود العطل كوحدة مستقلة
// ═══════════════════════════════════════════════════════

data class DtcCode(val raw: String) {
    val normalized: String get() = raw.uppercase().trim()
    val category: String get() = when (raw.firstOrNull()?.uppercaseChar()) {
        'P' -> "محرك / ناقل حركة"
        'C' -> "هيكل / شاسيه"
        'B' -> "كاروسيري / جسم"
        'U' -> "شبكة اتصال CAN"
        else -> "غير محدد"
    }
}
