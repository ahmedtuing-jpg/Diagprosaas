package com.diagpro.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.detection.DtcDebouncer
import com.diagpro.assistant.detection.DtcExtractor
import com.diagpro.assistant.detection.VehicleInfoExtractor
import com.diagpro.assistant.overlay.FloatingOverlayService
import com.diagpro.assistant.util.Constants
import com.google.gson.Gson

/**
 * Accessibility Service — قلب النظام
 *
 * يراقب X-Diag فقط، يستخرج:
 * - أكواد DTC
 * - بيانات السيارة (تلقائياً)
 * ثم يُبلّغ FloatingOverlayService
 */
class XDiagAccessibilityService : AccessibilityService() {

    private val TAG      = "XDiagService"
    private val debouncer = DtcDebouncer()
    private val gson     = Gson()

    private var lastCodes  = listOf<String>()
    private var lastVehicle: VehicleInfo? = null

    // ═══════════════════════════════════════════════════
    //  دورة الحياة
    // ═══════════════════════════════════════════════════

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "✅ Accessibility متصلة — تراقب: ${Constants.XDIAG_PACKAGE_NAME}")
        ensureOverlayRunning()
    }

    override fun onInterrupt() {
        debouncer.cancel()
        Log.w(TAG, "⚠️ Accessibility انقطعت")
    }

    override fun onDestroy() {
        debouncer.cancel()
        super.onDestroy()
    }

    // ═══════════════════════════════════════════════════
    //  معالجة الأحداث
    // ═══════════════════════════════════════════════════

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != Constants.XDIAG_PACKAGE_NAME) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> onScreenChanged()
            else -> { }
        }
    }

    // ═══════════════════════════════════════════════════
    //  منطق الكشف
    // ═══════════════════════════════════════════════════

    private fun onScreenChanged() {
        debouncer.debounce {
            val root = rootInActiveWindow ?: run { handleNoCodes(); return@debounce }
            val text = ScreenTextReader.readAll(root)
            root.recycle()

            // استخراج الأكواد
            val codes = DtcExtractor.extract(text)

            // استخراج بيانات السيارة (تلقائياً)
            val vehicle = VehicleInfoExtractor.extract(text)
            if (vehicle != null && vehicle != lastVehicle) {
                lastVehicle = vehicle
                notifyVehicleDetected(vehicle)
            }

            if (codes.isEmpty()) {
                handleNoCodes()
            } else if (DtcExtractor.hasChanged(lastCodes, codes)) {
                lastCodes = codes
                notifyCodes(codes)
            }
        }
    }

    private fun notifyCodes(codes: List<String>) {
        Log.d(TAG, "🔍 أكواد: $codes")
        startService(
            Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_SHOW
                putStringArrayListExtra(FloatingOverlayService.EXTRA_CODES, ArrayList(codes))
                lastVehicle?.let {
                    putExtra(FloatingOverlayService.EXTRA_VEHICLE_JSON, gson.toJson(it))
                }
            }
        )
    }

    private fun notifyVehicleDetected(vehicle: VehicleInfo) {
        Log.d(TAG, "🚗 سيارة مكتشفة: ${vehicle.displayName()}")
        startService(
            Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_UPDATE_VEHICLE
                putExtra(FloatingOverlayService.EXTRA_VEHICLE_JSON, gson.toJson(vehicle))
            }
        )
    }

    private fun handleNoCodes() {
        if (lastCodes.isNotEmpty()) {
            lastCodes = emptyList()
            startService(Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_HIDE
            })
        }
    }

    private fun ensureOverlayRunning() {
        startService(Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_START
        })
    }
}
