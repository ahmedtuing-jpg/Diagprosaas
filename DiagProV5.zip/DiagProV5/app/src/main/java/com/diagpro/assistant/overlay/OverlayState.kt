package com.diagpro.assistant.overlay

import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.VehicleInfo

sealed class OverlayState {
    object Hidden : OverlayState()

    data class BubbleOnly(
        val codes      : List<String>,
        val vehicle    : VehicleInfo? = null
    ) : OverlayState()

    data class DrawerLoading(
        val codes      : List<String>,
        val selectedCode: String,
        val vehicle    : VehicleInfo? = null
    ) : OverlayState()

    data class DrawerReady(
        val codes       : List<String>,
        val selectedCode: String,
        val analysis    : AnalysisResult,
        val vehicle     : VehicleInfo? = null,
        val savedCaseId : Long? = null
    ) : OverlayState()
}
