package com.diagpro.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.diagpro.assistant.DiagProApp
import com.diagpro.assistant.R
import com.diagpro.assistant.accessibility.XDiagAccessibilityService
import com.diagpro.assistant.overlay.FloatingOverlayService
import com.diagpro.assistant.util.*
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        const val ACTION_OPEN_REPORT       = "diagpro.OPEN_REPORT"
        const val EXTRA_CODES_FOR_REPORT   = "extra_codes_for_report"
        const val EXTRA_VEHICLE_MAKE       = "extra_vehicle_make"
        const val EXTRA_VEHICLE_MODEL      = "extra_vehicle_model"
        const val EXTRA_VEHICLE_YEAR       = "extra_vehicle_year"
        const val EXTRA_VEHICLE_VIN        = "extra_vehicle_vin"
    }

    // ── حالة النظام ──────────────────────────────
    private lateinit var tvAccessStatus : TextView
    private lateinit var tvOverlayStatus: TextView
    private lateinit var btnAccess      : Button
    private lateinit var btnOverlay     : Button
    private lateinit var btnStart       : Button
    private lateinit var btnStop        : Button
    private lateinit var tvDbInfo       : TextView

    // ── مزوّد AI ──────────────────────────────────
    private lateinit var rgAiProvider   : RadioGroup
    private lateinit var layoutClaude   : LinearLayout
    private lateinit var layoutOpenAi   : LinearLayout
    private lateinit var etClaudeKey    : EditText
    private lateinit var etOpenAiKey    : EditText
    private lateinit var btnSaveAi      : Button

    // ── DiagPro Cloud ──────────────────────────────
    private lateinit var switchCloud    : Switch
    private lateinit var layoutCloud    : LinearLayout
    private lateinit var etCloudUrl     : EditText
    private lateinit var etCloudKey     : EditText
    private lateinit var etWorkshopId   : EditText
    private lateinit var etTechName     : EditText
    private lateinit var btnSaveCloud   : Button

    // ─────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        loadSavedConfig()
        setupListeners()
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIncomingIntent(it) }
    }

    // ═══════════════════════════════════════════════
    //  ربط الـ Views
    // ═══════════════════════════════════════════════

    private fun bindViews() {
        tvAccessStatus  = findViewById(R.id.tvAccessStatus)
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        btnAccess       = findViewById(R.id.btnEnableAccess)
        btnOverlay      = findViewById(R.id.btnEnableOverlay)
        btnStart        = findViewById(R.id.btnStart)
        btnStop         = findViewById(R.id.btnStop)
        tvDbInfo        = findViewById(R.id.tvDbInfo)

        rgAiProvider    = findViewById(R.id.rgAiProvider)
        layoutClaude    = findViewById(R.id.layoutClaude)
        layoutOpenAi    = findViewById(R.id.layoutOpenAi)
        etClaudeKey     = findViewById(R.id.etClaudeKey)
        etOpenAiKey     = findViewById(R.id.etOpenAiKey)
        btnSaveAi       = findViewById(R.id.btnSaveAi)

        switchCloud     = findViewById(R.id.switchCloud)
        layoutCloud     = findViewById(R.id.layoutCloud)
        etCloudUrl      = findViewById(R.id.etCloudUrl)
        etCloudKey      = findViewById(R.id.etCloudKey)
        etWorkshopId    = findViewById(R.id.etWorkshopId)
        etTechName      = findViewById(R.id.etTechName)
        btnSaveCloud    = findViewById(R.id.btnSaveCloud)
    }

    // ═══════════════════════════════════════════════
    //  تحميل الإعدادات المحفوظة
    // ═══════════════════════════════════════════════

    private fun loadSavedConfig() {
        val p = prefs()

        // AI Provider
        when (p.getString(Constants.PREF_AI_PROVIDER, "LOCAL")) {
            "CLAUDE" -> { rgAiProvider.check(R.id.rbClaude); showAiLayout("CLAUDE") }
            "OPENAI" -> { rgAiProvider.check(R.id.rbOpenAi); showAiLayout("OPENAI") }
            else     -> { rgAiProvider.check(R.id.rbLocal);  showAiLayout("LOCAL") }
        }
        etClaudeKey.setText(p.getString(Constants.PREF_CLAUDE_KEY, ""))
        etOpenAiKey.setText(p.getString(Constants.PREF_OPENAI_KEY, ""))

        // Cloud
        val useCloud = p.getBoolean(Constants.PREF_USE_CLOUD, false)
        switchCloud.isChecked = useCloud
        layoutCloud.visibility = if (useCloud) View.VISIBLE else View.GONE
        etCloudUrl.setText(p.getString(Constants.PREF_CLOUD_URL, Constants.DEFAULT_CLOUD_URL))
        etCloudKey.setText(p.getString(Constants.PREF_CLOUD_KEY, ""))
        etWorkshopId.setText(p.getString(Constants.PREF_WORKSHOP_ID, "diagpro_workshop_1"))
        etTechName.setText(p.getString(Constants.PREF_TECHNICIAN_NAME, ""))
    }

    // ═══════════════════════════════════════════════
    //  المستمعون
    // ═══════════════════════════════════════════════

    private fun setupListeners() {

        btnAccess.setOnClickListener { openAccessibilitySettings() }
        btnOverlay.setOnClickListener { openOverlaySettings() }

        btnStart.setOnClickListener {
            startService(Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_START
            })
            showToast("DiagPro Assistant يعمل ✅")
            refreshStatus()
        }

        btnStop.setOnClickListener {
            startService(Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_STOP
            })
            showToast("تم إيقاف الخدمة")
        }

        // AI Provider selection
        rgAiProvider.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbClaude  -> showAiLayout("CLAUDE")
                R.id.rbOpenAi  -> showAiLayout("OPENAI")
                else           -> showAiLayout("LOCAL")
            }
        }

        btnSaveAi.setOnClickListener {
            val provider = when (rgAiProvider.checkedRadioButtonId) {
                R.id.rbClaude  -> "CLAUDE"
                R.id.rbOpenAi  -> "OPENAI"
                else           -> "LOCAL"
            }
            prefs().edit()
                .putString(Constants.PREF_AI_PROVIDER, provider)
                .putString(Constants.PREF_CLAUDE_KEY,  etClaudeKey.text.toString().trim())
                .putString(Constants.PREF_OPENAI_KEY,  etOpenAiKey.text.toString().trim())
                .apply()
            showToast("✅ تم حفظ إعدادات AI")
        }

        // Cloud toggle
        switchCloud.setOnCheckedChangeListener { _, checked ->
            layoutCloud.visibility = if (checked) View.VISIBLE else View.GONE
            prefs().edit().putBoolean(Constants.PREF_USE_CLOUD, checked).apply()
        }

        btnSaveCloud.setOnClickListener {
            val url = etCloudUrl.text.toString().trim()
            val key = etCloudKey.text.toString().trim()
            val wid = etWorkshopId.text.toString().trim()
            val tec = etTechName.text.toString().trim()
            if (url.isBlank() || key.isBlank()) {
                showToast("⚠️ أدخل رابط API ومفتاح الورشة"); return@setOnClickListener
            }
            prefs().edit()
                .putString(Constants.PREF_CLOUD_URL,        url)
                .putString(Constants.PREF_CLOUD_KEY,        key)
                .putString(Constants.PREF_WORKSHOP_ID,      wid)
                .putString(Constants.PREF_TECHNICIAN_NAME,  tec)
                .apply()
            showToast("✅ تم حفظ إعدادات DiagPro Cloud")
        }

        // زر تقارير الصيانة
        findViewById<Button>(R.id.btnViewReports)?.setOnClickListener {
            startActivity(Intent(this, ReportsListActivity::class.java))
        }

        // اسم الحزمة
        findViewById<TextView>(R.id.tvPackageName)?.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("اسم حزمة X-Diag")
                .setMessage(
                    "الحزمة الحالية:\ncom.xdiag.android\n\n" +
                    "للتحقق:\nadb shell pm list packages | grep -i xdiag\n\n" +
                    "بعد التحقق غيّر XDIAG_PACKAGE_NAME في Constants.kt\n" +
                    "وعدّل accessibility_service_config.xml"
                )
                .setPositiveButton("موافق", null)
                .show()
        }
    }

    // ═══════════════════════════════════════════════
    //  تحديث واجهة الحالة
    // ═══════════════════════════════════════════════

    private fun refreshStatus() {
        val accessOk  = isAccessibilityEnabled()
        val overlayOk = Settings.canDrawOverlays(this)

        tvAccessStatus.text  = if (accessOk)  "✅ مفعّل" else "❌ غير مفعّل"
        tvOverlayStatus.text = if (overlayOk) "✅ مفعّل" else "❌ غير مفعّل"

        fun color(ok: Boolean) = if (ok)
            resources.getColor(R.color.status_ok) else resources.getColor(R.color.status_error)

        tvAccessStatus.setTextColor(color(accessOk))
        tvOverlayStatus.setTextColor(color(overlayOk))
        btnAccess.text  = if (accessOk)  "مفعّل ✅" else "تفعيل"
        btnOverlay.text = if (overlayOk) "مفعّل ✅" else "تفعيل"
        btnAccess.isEnabled  = !accessOk
        btnOverlay.isEnabled = !overlayOk
        btnStart.isEnabled   = accessOk && overlayOk

        val app = application as DiagProApp
        tvDbInfo.text = "قاعدة DTC المحلية: ${app.localDbSize} كود"

        lifecycleScope.launch {
            val db    = app.database
            val total = db.caseDao().let { 0 }  // placeholder — نجلب العدد بشكل آمن
            val rep   = db.reportDao().let { 0 }
        }
    }

    private fun showAiLayout(provider: String) {
        layoutClaude.visibility = if (provider == "CLAUDE") View.VISIBLE else View.GONE
        layoutOpenAi.visibility = if (provider == "OPENAI") View.VISIBLE else View.GONE
    }

    private fun openAccessibilitySettings() {
        showToast("ابحث عن DiagPro Assistant وفعّله", long = true)
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")))
    }

    private fun isAccessibilityEnabled(): Boolean {
        val svc = "$packageName/${XDiagAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return TextUtils.SimpleStringSplitter(':').apply { setString(enabled) }
            .any { it.equals(svc, ignoreCase = true) }
    }

    // Intent من الـ Overlay يفتح تقرير الصيانة مباشرة
    private fun handleIncomingIntent(intent: Intent) {
        if (intent.action == ACTION_OPEN_REPORT) {
            val codes = intent.getStringArrayListExtra(EXTRA_CODES_FOR_REPORT) ?: return
            startActivity(Intent(this, RepairReportActivity::class.java).apply {
                putStringArrayListExtra(RepairReportActivity.EXTRA_PRE_CODES, codes)
                putExtra(RepairReportActivity.EXTRA_VEHICLE_MAKE,  intent.getStringExtra(EXTRA_VEHICLE_MAKE) ?: "")
                putExtra(RepairReportActivity.EXTRA_VEHICLE_MODEL, intent.getStringExtra(EXTRA_VEHICLE_MODEL) ?: "")
                putExtra(RepairReportActivity.EXTRA_VEHICLE_YEAR,  intent.getIntExtra(EXTRA_VEHICLE_YEAR, 0))
                putExtra(RepairReportActivity.EXTRA_VEHICLE_VIN,   intent.getStringExtra(EXTRA_VEHICLE_VIN) ?: "")
            })
        }
    }
}
