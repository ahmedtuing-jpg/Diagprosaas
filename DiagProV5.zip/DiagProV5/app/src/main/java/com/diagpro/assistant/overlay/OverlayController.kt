package com.diagpro.assistant.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diagpro.assistant.R
import com.diagpro.assistant.analysis.model.AnalysisResult
import com.diagpro.assistant.analysis.model.VehicleInfo
import com.diagpro.assistant.ui.adapter.CauseAdapter
import com.diagpro.assistant.ui.adapter.DtcChipAdapter
import com.diagpro.assistant.ui.adapter.ProbabilityAdapter
import com.diagpro.assistant.ui.adapter.StepAdapter
import com.diagpro.assistant.util.Constants
import com.diagpro.assistant.util.dpToPx

class OverlayController(
    private val context             : Context,
    private val onBubbleClick       : () -> Unit,
    private val onSaveCaseClick     : (codes: List<String>, code: String, notes: String) -> Unit,
    private val onMarkSolvedClick   : (caseId: Long?) -> Unit,
    private val onReportClick       : () -> Unit
) {
    private val TAG = "OverlayController"
    private val wm  = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var bubbleView : View? = null
    private var drawerView : View? = null
    private var bParams    : WindowManager.LayoutParams? = null
    private var bx         = context.dpToPx(Constants.BUBBLE_DEFAULT_X)
    private var by         = context.dpToPx(Constants.BUBBLE_DEFAULT_Y)

    var onChipSelected: (String) -> Unit = {}

    // ═══════════════════════════════════════════════
    //  Window type compatible with Android 7.1
    // ═══════════════════════════════════════════════
    @Suppress("DEPRECATION")
    private val windowType get() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

    // ═══════════════════════════════════════════════
    //  Bubble
    // ═══════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    fun showBubble(codes: List<String>, vehicle: VehicleInfo?) {
        if (bubbleView == null) createBubble()
        updateBubble(codes)
        vibrate()
    }

    fun updateBubble(codes: List<String>) {
        val v = bubbleView ?: return
        v.findViewById<TextView>(R.id.tvBubbleCode)?.text  = codes.firstOrNull() ?: ""
        val tvCount = v.findViewById<TextView>(R.id.tvBubbleCount)
        if (codes.size > 1) { tvCount?.visibility = View.VISIBLE; tvCount?.text = "+${codes.size - 1}" }
        else tvCount?.visibility = View.GONE
    }

    fun hideBubble() {
        remove(bubbleView); bubbleView = null
        remove(drawerView); drawerView = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val inflater = LayoutInflater.from(context)
        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)

        bParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = bx; y = by }

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var dragging = false

        bubbleView?.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = bParams?.x ?: 0; iy = bParams?.y ?: 0
                    tx = e.rawX; ty = e.rawY; dragging = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                        dragging = true
                        bParams?.x = ix + dx; bParams?.y = iy + dy
                        try { bubbleView?.let { wm.updateViewLayout(it, bParams) } } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    bx = bParams?.x ?: bx; by = bParams?.y ?: by
                    if (!dragging) onBubbleClick()
                    true
                }
                else -> false
            }
        }
        try { wm.addView(bubbleView, bParams) } catch (e: Exception) { Log.e(TAG, "addBubble: ${e.message}") }
    }

    // ═══════════════════════════════════════════════
    //  Drawer
    // ═══════════════════════════════════════════════

    fun openDrawer(codes: List<String>, vehicle: VehicleInfo?) {
        if (drawerView != null) return
        val inflater = LayoutInflater.from(context)
        drawerView   = inflater.inflate(R.layout.layout_analysis_drawer, null)

        val dp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }

        val dv = drawerView!!

        // زر الإغلاق
        dv.findViewById<ImageButton>(R.id.btnClose)?.setOnClickListener { closeDrawer() }

        // شرائح الأكواد
        setupChips(dv, codes)

        // معلومات السيارة
        updateVehicleDisplay(dv, vehicle)

        // أزرار الإجراءات
        dv.findViewById<Button>(R.id.btnSaveCase)?.setOnClickListener {
            val notes = dv.findViewById<EditText>(R.id.etNotes)?.text?.toString() ?: ""
            val chips = (dv.findViewById<RecyclerView>(R.id.rvDtcChips)?.adapter as? DtcChipAdapter)
            val selectedCode = chips?.getSelectedCode() ?: codes.firstOrNull() ?: ""
            onSaveCaseClick(codes, selectedCode, notes)
        }
        dv.findViewById<Button>(R.id.btnMarkSolved)?.setOnClickListener {
            onMarkSolvedClick(null)
        }
        dv.findViewById<Button>(R.id.btnReport)?.setOnClickListener {
            onReportClick()
        }
        dv.findViewById<Button>(R.id.btnCloseDrawer)?.setOnClickListener { closeDrawer() }

        try {
            wm.addView(dv, dp)
            dv.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_up))
        } catch (e: Exception) { Log.e(TAG, "addDrawer: ${e.message}") }
    }

    fun showLoading() {
        val dv = drawerView ?: return
        dv.findViewById<ProgressBar>(R.id.progressAnalysis)?.visibility = View.VISIBLE
        dv.findViewById<ScrollView>(R.id.scrollContent)?.visibility     = View.GONE
        dv.findViewById<LinearLayout>(R.id.layoutActions)?.visibility   = View.GONE
    }

    fun showAnalysis(analysis: AnalysisResult, savedCaseId: Long?) {
        val dv = drawerView ?: return
        dv.findViewById<ProgressBar>(R.id.progressAnalysis)?.visibility = View.GONE
        dv.findViewById<ScrollView>(R.id.scrollContent)?.visibility     = View.VISIBLE
        dv.findViewById<LinearLayout>(R.id.layoutActions)?.visibility   = View.VISIBLE

        dv.findViewById<TextView>(R.id.tvCode)?.text   = analysis.code
        dv.findViewById<TextView>(R.id.tvNameAr)?.text = analysis.nameAr

        val tvSev = dv.findViewById<TextView>(R.id.tvSeverity)
        tvSev?.text = analysis.severity.labelAr
        try { tvSev?.setBackgroundColor(android.graphics.Color.parseColor(analysis.severity.colorHex)) }
        catch (_: Exception) {}

        dv.findViewById<TextView>(R.id.tvDescription)?.text  = analysis.description
        dv.findViewById<TextView>(R.id.tvAnalysisSource)?.text = when (analysis.source) {
            com.diagpro.assistant.analysis.model.AnalysisSource.DIAGPRO_CLOUD -> "📡 DiagPro Cloud"
            com.diagpro.assistant.analysis.model.AnalysisSource.AI_CLAUDE     -> "🤖 Claude AI"
            com.diagpro.assistant.analysis.model.AnalysisSource.AI_OPENAI     -> "🤖 GPT-4o"
            else -> "💾 قاعدة محلية"
        }

        // احتماليات الأسباب (من DiagPro Cloud أو AI)
        val layoutProb = dv.findViewById<LinearLayout>(R.id.layoutProbabilities)
        val rvProb     = dv.findViewById<RecyclerView>(R.id.rvProbabilities)
        if (analysis.probabilities.isNotEmpty()) {
            layoutProb?.visibility = View.VISIBLE
            rvProb?.layoutManager  = LinearLayoutManager(context)
            rvProb?.isNestedScrollingEnabled = false
            rvProb?.adapter = ProbabilityAdapter(analysis.probabilities)
        } else layoutProb?.visibility = View.GONE

        // الأسباب
        val rvCauses = dv.findViewById<RecyclerView>(R.id.rvCauses)
        rvCauses?.layoutManager = LinearLayoutManager(context)
        rvCauses?.isNestedScrollingEnabled = false
        rvCauses?.adapter = CauseAdapter(analysis.causes)

        // الخطوات
        val rvSteps = dv.findViewById<RecyclerView>(R.id.rvSteps)
        rvSteps?.layoutManager = LinearLayoutManager(context)
        rvSteps?.isNestedScrollingEnabled = false
        rvSteps?.adapter = StepAdapter(analysis.steps)

        // ملاحظة خاصة
        val tvSpec = dv.findViewById<TextView>(R.id.tvSpecialNotes)
        if (analysis.specialNotes.isNotBlank()) {
            tvSpec?.visibility = View.VISIBLE
            tvSpec?.text = "⚠️ ${analysis.specialNotes}"
        } else tvSpec?.visibility = View.GONE

        // زر "تم الحل"
        dv.findViewById<Button>(R.id.btnMarkSolved)?.let { btn ->
            btn.visibility = if (savedCaseId != null) View.VISIBLE else View.GONE
            btn.setOnClickListener { onMarkSolvedClick(savedCaseId) }
        }
    }

    fun onCaseSaved(id: Long) {
        drawerView?.let { dv ->
            dv.findViewById<Button>(R.id.btnSaveCase)?.apply { text = "✅ محفوظ"; isEnabled = false }
            dv.findViewById<Button>(R.id.btnMarkSolved)?.visibility = View.VISIBLE
        }
    }

    fun onSolvedConfirmed() {
        drawerView?.let { dv ->
            dv.findViewById<Button>(R.id.btnMarkSolved)?.apply { text = "✅ مُحلول"; isEnabled = false }
        }
    }

    fun updateVehicleInDrawer(vehicle: VehicleInfo) {
        drawerView?.let { updateVehicleDisplay(it, vehicle) }
    }

    private fun updateVehicleDisplay(dv: View, vehicle: VehicleInfo?) {
        val tvVehicle = dv.findViewById<TextView>(R.id.tvVehicleInfo)
        if (vehicle != null && vehicle.isValid()) {
            tvVehicle?.visibility = View.VISIBLE
            val src = if (vehicle.source == VehicleInfo.VehicleSource.AUTO_DETECTED) "🚗" else "✏️"
            tvVehicle?.text = "$src ${vehicle.displayName()}"
        } else {
            tvVehicle?.visibility = View.GONE
        }
    }

    private fun setupChips(dv: View, codes: List<String>) {
        val rv = dv.findViewById<RecyclerView>(R.id.rvDtcChips) ?: return
        rv.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rv.adapter = DtcChipAdapter(codes, codes.firstOrNull() ?: "") { code ->
            onChipSelected(code)
        }
    }

    fun closeDrawer() { remove(drawerView); drawerView = null }
    fun isDrawerOpen() = drawerView != null

    private fun remove(v: View?) {
        v ?: return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    fun removeAll() { remove(bubbleView); bubbleView = null; remove(drawerView); drawerView = null }

    private fun vibrate() {
        try {
            val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vib.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vib.vibrate(80)
        } catch (_: Exception) {}
    }
}
